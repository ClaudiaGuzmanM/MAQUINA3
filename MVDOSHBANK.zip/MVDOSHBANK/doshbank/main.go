package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"os"
	"os/signal"
	"sync"
	"syscall"

	pb "github.com/EdwardFlowersGg/Lab4_INF-343/proto"
	"github.com/streadway/amqp"
	"google.golang.org/grpc"
)

type server struct {
	pb.UnimplementedKFserviceServer
	totalAmount int64
	mu          sync.Mutex
}

func failOnError(err error, msg string) {
	if err != nil {
		log.Fatalf("%s: %s", msg, err)
	}
}

func (s *server) SolicitarMontoDineroDirectorBanco(ctx context.Context, in *pb.MontoDineroDirectorBancoRequest) (*pb.MontoDineroResponse, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return &pb.MontoDineroResponse{Amount: float64(s.totalAmount)}, nil
}

// Función para procesar los mensajes de RabbitMQ
func (s *server) processMessages() {
	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
	failOnError(err, "Failed to connect to RabbitMQ")
	defer conn.Close()

	ch, err := conn.Channel()
	failOnError(err, "Failed to open a channel")
	defer ch.Close()

	q, err := ch.QueueDeclare(
		"mercenary_eliminations", // nombre de la cola
		true,                     // durable
		false,                    // delete when unused
		false,                    // exclusive
		false,                    // no-wait
		nil,                      // arguments
	)
	failOnError(err, "Failed to declare a queue")

	msgs, err := ch.Consume(
		q.Name, // nombre de la cola
		"",     // consumer
		true,   // auto-ack
		false,  // exclusive
		false,  // no-local
		false,  // no-wait
		nil,    // arguments
	)
	failOnError(err, "Failed to register a consumer")

	// Abrir el archivo de registro
	file, err := os.OpenFile("dosh_bank.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	failOnError(err, "Failed to open file")
	defer file.Close()

	for d := range msgs {
		message := string(d.Body)
		fmt.Println("Received a message:", message)

		// Parsear el mensaje y actualizar el monto acumulado
		var name string
		var floor int32
		var amount int64
		fmt.Sscanf(message, "%s %d %d", &name, &floor, &amount)

		s.mu.Lock()
		s.totalAmount += amount
		logMessage := fmt.Sprintf("%s Piso %d Monto acumulado actual: %d\n", name, floor, s.totalAmount)
		_, err = file.WriteString(logMessage)
		s.mu.Unlock()

		if err != nil {
			log.Printf("Failed to write to file: %s", err)
		}
	}
}

// Función para manejar las solicitudes HTTP y responder con el monto acumulado actual
//func handleRequests(w http.ResponseWriter, r *http.Request) {
//	mu.Lock()
//	defer mu.Unlock()
//	fmt.Fprintf(w, "Monto acumulado actual: %d", totalAmount)
//}

func main() {
	// Inicializar el monto acumulado
	s := grpc.NewServer()
	serv := &server{totalAmount: 0}
	pb.RegisterKFserviceServer(s, serv)

	lis, err := net.Listen("tcp", ":8080")
	if err != nil {
		log.Fatalf("Error al escuchar: %v", err)
	}

	go func() {
		if err := s.Serve(lis); err != nil {
			log.Fatalf("Failed to serve: %v", err)
		}
	}()

	go serv.processMessages()

	//http.HandleFunc("/monto", handleRequests)
	//go func() {
	//	log.Fatal(http.ListenAndServe(":8080", nil))
	//}()

	// Esperar a que se interrumpa el proceso (Ctrl+C)
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)
	<-sigChan

	fmt.Println("Dosh Bank cerrado.")
}
